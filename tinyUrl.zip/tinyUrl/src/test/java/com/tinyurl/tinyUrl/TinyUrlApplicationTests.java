package com.tinyurl.tinyUrl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TinyUrlApplicationTests {

	@Test
	void contextLoads() {
	}

}
